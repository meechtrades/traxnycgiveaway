DLL SIDELOAD + PROCESS INJECTION
================================

Method: DLL Hijacking + Remote Process Injection
DLL Template: mscorsvc.dll
Target Process: explorer.exe

Files:
- SystemService.exe (Loader executable)
- mscorsvc.dll (Malicious DLL)

Instructions:
1. Extract BOTH files to SAME directory
2. Run SystemService.exe
3. Payload injects into explorer.exe for stealth
4. Loader exits after 5 seconds

Technical Flow:
SystemService.exe → Loads mscorsvc.dll → Injects into explorer.exe → Loader exits cleanly

Features:
- Payload runs in explorer.exe context
- Loader process exits after injection
- No orphaned processes
- Maximum stealth
